package com.cg.dao;

import java.util.List;

import com.cg.entities.Inventory;
import com.cg.entities.SoldItems;

public interface IQueryDAO {
	
	void plp();
	public  List<SoldItems> statusUpdate(int id);
}
