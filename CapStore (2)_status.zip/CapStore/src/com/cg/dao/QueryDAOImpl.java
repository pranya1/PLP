package com.cg.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00, 0.00);
	     SoldItems solditems=new SoldItems(customer,inventory, "dghsfgj", new Date());
	     inventory.setMerchant(merchant);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.persist(solditems);
	     entityManager.flush();
		
	}

	public  List<SoldItems> statusUpdate(int id)
	{	
	//Merchant merchants=entityManager.find(Merchant.class,id);
	//Inventory merchants=entityManager.find(Inventory.class,id);
	//System.out.println(merchants);
	TypedQuery<SoldItems> status=entityManager.createQuery("Select c from SoldItems c where c.inventory.merchant.merchantId=2",SoldItems.class);
	//status.setParameter("in",merchants);
	//System.out.println(merchants);
	List<SoldItems> items=status.getResultList();
	for(SoldItems soldItems:items)
		System.out.println(soldItems);
		
	return items;
	}
	
	
	
}
