package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.util.SystemPropertyUtils;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void plp() {
		 Admin admin=new Admin("griet", "griet@gmail.com", "apassword", 20.0);
	     Customer customer=new Customer("cust@gmail.com", "cpassword", "fead", "fewre");
	     Merchant merchant=new Merchant("merc@gmail.com", "mpassword", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00);
	     inventory.setMerchant(merchant);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.flush();
		
	}

	@Override
	public Merchant saveMerchant(Merchant merchant) {
		merchant.setMoney(0.00);
		merchant.setNoOfRatings(0);
		merchant.setRating(0.00);
		TypedQuery<Customer> query1=entityManager.createQuery("select c from Customer c",Customer.class);
		List<Customer> customers=query1.getResultList();
		int flag=0;
		for(Customer customer2:customers)
		{
			System.out.println(customer2.getEmailId());
			if(customer2.getEmailId().equals(merchant.getEmailId()))
			{
				flag=1;
				System.out.println("exist");
				break;
			}
		}
		if(flag==1)
			throw new ArithmeticException();
		TypedQuery<Merchant> query=entityManager.createQuery("select c from Merchant c",Merchant.class);
		List<Merchant> merchants=query.getResultList();
		for(Merchant merchant2:merchants)
		{
			if(merchant2.getEmailId().equals(merchant.getEmailId()))
			{
				flag=1;
				break;
			}
		}
		if(flag==1)
			throw new ArithmeticException(); 
		if(merchant.getEmailId().equals("aswin@gmail.com"))
			throw new ArithmeticException();
			entityManager.persist(merchant);
			entityManager.flush();
			return merchant;
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		TypedQuery<Customer> query=entityManager.createQuery("select c from Customer c",Customer.class);
		List<Customer> customers=query.getResultList();
		int flag=0;
		for(Customer customer2:customers)
		{
			System.out.println(customer2.getEmailId());
			if(customer2.getEmailId().equals(customer.getEmailId()))
			{
				flag=1;
				System.out.println("exist");
				break;
			}
		}
		if(flag==1)
			throw new ArithmeticException(); 
		TypedQuery<Merchant> query1=entityManager.createQuery("select c from Merchant c",Merchant.class);
		List<Merchant> merchants=query1.getResultList();
		for(Merchant merchant2:merchants)
		{
			if(merchant2.getEmailId().equals(customer.getEmailId()))
			{
				flag=1;
				break;
			}
		}
		if(flag==1)
			throw new ArithmeticException();
		if(customer.getEmailId().equals("aswin@gmail.com"))
			throw new ArithmeticException();
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
	}

	@Override
	public String decryptPassword(String password) {
		StringBuffer encryptPassword=new StringBuffer();
		int id=1;
		for(int i=0;i<password.length();i++) {
			int ascii=(int)password.charAt(i)-id*i;
			String j=Character.toString((char)ascii);
			encryptPassword.append(j);
		}
		return encryptPassword.toString();
		//return null;
	}

	
}
