package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void plp() {
		 Admin admin=new Admin("griet", "griet@gmail.com", "apassword", 20.0);
	     Customer customer=new Customer("cust@gmail.com", "cpassword", "fead", "fewre");
	     Merchant merchant=new Merchant("merc@gmail.com", "mpassword", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00);
	     inventory.setMerchant(merchant);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.flush();
		
	}

	@Override
	public Merchant saveMerchant(Merchant merchant) {
		merchant.setMoney(0.00);
		merchant.setNoOfRatings(0);
		merchant.setRating(0.00);
			entityManager.persist(merchant);
			entityManager.flush();
			return merchant;
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
	}

	@Override
	public String decryptPassword(String password) {
		StringBuffer encryptPassword=new StringBuffer();
		int id=1;
		for(int i=0;i<password.length();i++) {
			int ascii=(int)password.charAt(i)-id*i;
			String j=Character.toString((char)ascii);
			encryptPassword.append(j);
		}
		return encryptPassword.toString();
		//return null;
	}

	
}
