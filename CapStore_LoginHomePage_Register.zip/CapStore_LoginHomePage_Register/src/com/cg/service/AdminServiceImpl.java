package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IAdminDAO;
import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;


@Service
@Transactional
public class AdminServiceImpl implements IAdminService{

	@Autowired
	IAdminDAO iAdminDAO;
	
	@Override
	public Admin isAdmin(String userName, String userPassword) {
		// TODO Auto-generated method stub
		return iAdminDAO.isAdmin(userName,userPassword);
	}

	@Override
	public String getAdminPassword(String userName) {
		// TODO Auto-generated method stub
		return iAdminDAO.getAdminPassword(userName);
	}

	@Override
	public List<Merchant> ViewallMerchant() {
		// TODO Auto-generated method stub
		return iAdminDAO.ViewallMerchant();
	}

	@Override
	public List<Inventory> ViewallInventory() {
		// TODO Auto-generated method stub
		return iAdminDAO.ViewallInventory();
	}

	@Override
	public List<Customer> ViewallCustomer() {
		// TODO Auto-generated method stub
		return iAdminDAO.ViewallCustomer();
	}

	@Override
	public boolean removeMerchant(int merchant) {
		// TODO Auto-generated method stub
		return iAdminDAO.removeMerchant(merchant);
	}

	@Override
	public boolean removeInventory(int inventory) {
		// TODO Auto-generated method stub
		return iAdminDAO.removeInventory(inventory);
	}

}
