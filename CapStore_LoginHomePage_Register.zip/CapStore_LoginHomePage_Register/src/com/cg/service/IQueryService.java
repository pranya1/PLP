package com.cg.service;

import java.util.List;

import com.cg.entities.Customer;
import com.cg.entities.Merchant;

public interface IQueryService {
	// List<QueryAnswers> getall();
	void plp();
	public Merchant saveMerchant(Merchant merchant);
	public Customer saveCustomer(Customer customer);
}
