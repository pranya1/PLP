package com.cg.dao;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;




@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00, 0.00);
	     inventory.setMerchant(merchant);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.flush();
		
	}



	
	@Override
	public Inventory find(int inventoryId) {
		
		
	/*Inventory inventory= entityManager.find(Inventory.class, inventoryId);
		   Customer customer=new Customer();
		  //  customer.setWishList(inventory);
		    entityManager.persist(inventory);
		     entityManager.persist(customer);
		     entityManager.flush();
		     return inventory;*/
		return entityManager.find(Inventory.class, inventoryId);

	}
	@Override	
	public List<Inventory> showwishlist() {
		TypedQuery<Inventory> query=entityManager.createQuery("select s from Inventory s",Inventory.class);
		System.out.println(query.getResultList());
		return query.getResultList();
	}




	@Override
	public Inventory moveitems(int inv) {
		Inventory invent=entityManager.find(Inventory.class, inv);
		   Customer customer=entityManager.find(Customer.class, 12);
		   customer.getWishList().add(invent);
//customer.setWishList(invent);		  
//entityManager.persist(invent);
//TypedQuery<Collection> query=entityManager.createQuery("select s.Inventory from Customer s",Collection.class);

		return invent;
	}
	@Override
	public Customer findCust(int customerId) {
		Customer cust=entityManager.find(Customer.class, customerId);
		return cust;	
	}
	@Override
	public void addWishList(Inventory item, int customerId) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public List<Inventory> getWishList(int customerId) {
		   Customer customer=entityManager.find(Customer.class, customerId);

		return customer.getWishList();
	}
	
}
