package com.cg.dao;

import java.util.List;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;

public interface IQueryDAO {
	Inventory find(int inventoryId);
	void plp();
	public List<Inventory> showwishlist();
	public Inventory moveitems(int inv);
	Customer findCust(int customerId);
	void addWishList(Inventory item, int customerId);
	List<Inventory> getWishList(int customerId);


}
