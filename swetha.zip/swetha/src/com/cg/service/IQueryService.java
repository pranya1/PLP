package com.cg.service;

import java.util.List;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;

public interface IQueryService {

	// List<QueryAnswers> getall();
	Inventory find(int inventoryId);
	public List<Inventory> showwishlist();
void plp();
 Inventory moveitems(int inv);
	Customer findCust(int customerId);
	void addWishList(Inventory item, int customerId);
	List<Inventory> getWishList(int customerId);

}
