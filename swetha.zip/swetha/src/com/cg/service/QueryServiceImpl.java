package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDAO;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;

@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDAO iQueryDAO;
	
	

	@Override
	public void plp() {
		iQueryDAO.plp();
	}



	@Override
	public Inventory find(int inventoryId) {
		
		return  iQueryDAO.find(inventoryId);
	}	

	@Override
	public List<Inventory> showwishlist() {
	
		return iQueryDAO.showwishlist();
	}



	@Override
	public Inventory moveitems(int inv) {
		 return iQueryDAO.moveitems(inv);
	}



	@Override
	public Customer findCust(int customerId) {
		// TODO Auto-generated method stub
		return iQueryDAO.findCust(customerId);
	}



	@Override
	public void addWishList(Inventory item,int customerId) {
		// TODO Auto-generated method stub
		iQueryDAO.addWishList(item,customerId);
	}



	@Override
	public List<Inventory> getWishList(int customerId) {
		// TODO Auto-generated method stub
		return iQueryDAO.getWishList(customerId);
	}



	
		
		
	}	

