package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.xml.ws.RequestWrapper;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.service.IQueryService;

@Controller
public class QueryController {
	
	@Autowired
	IQueryService iQueryService;
	
	
	@RequestMapping("/index")
	public String index(Model model) {
		//iQueryService.plp();
		model.addAttribute("wishlistitems",iQueryService.showwishlist());
		return "index";
	}
	@RequestMapping("/wishlist")
	public String show(@RequestParam("itemId") String inventoryId, Model model)
			{
		int customerId=12;
		
		Inventory item=iQueryService.moveitems(Integer.parseInt(inventoryId));
		Customer cust=iQueryService.findCust(customerId);
		model.addAttribute("item", iQueryService.getWishList(customerId));
		return "wishlist";	
		}
	}
	