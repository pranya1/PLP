package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.dao.IMerchantDao;

public class MerchantServiceImple implements IMerchantService{
	@Autowired
IMerchantDao iMerchantDao;
/*	@Override
	public void viewInventory() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addProducts() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeProduct() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addDiscount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeDiscount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkOrders() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void promos() {
		// TODO Auto-generated method stub
		
	}*/

	@Override
	public void plp() {
		iMerchantDao.plp();
	}

	
}
