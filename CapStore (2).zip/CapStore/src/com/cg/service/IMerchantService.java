package com.cg.service;

public interface IMerchantService {
/*public void viewInventory();
public void addProducts();
public void removeProduct();
public void addDiscount();
public void removeDiscount();
public void checkOrders();
public void promos();*/
public void plp();
}
