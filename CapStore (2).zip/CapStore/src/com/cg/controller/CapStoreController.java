package com.cg.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.web.bind.annotation.RequestMapping;


import com.cg.service.IMerchantService;


@Controller
public class CapStoreController {
	
	@Autowired
	IMerchantService iMerchantService;
	
	
	@RequestMapping("/index")
	public String index() {
		iMerchantService.plp();
		return "index";
	}
	
	
}
