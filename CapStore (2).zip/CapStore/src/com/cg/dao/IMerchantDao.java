package com.cg.dao;

public interface IMerchantDao {
	/*public void viewInventory();
	public void addProducts();
	public void removeProduct();
	public void addDiscount();
	public void removeDiscount();
	public void checkOrders();
	public void promos();*/
	public void plp();
}
