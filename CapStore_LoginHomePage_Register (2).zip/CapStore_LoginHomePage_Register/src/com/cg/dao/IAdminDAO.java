package com.cg.dao;

import java.util.List;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

public interface IAdminDAO {

	Admin isAdmin(String userName, String userPassword);
	String getAdminPassword(String userName);
	List<Merchant> ViewallMerchant();
	List<Inventory> ViewallInventory();
	List<Customer> ViewallCustomer();
	boolean removeMerchant(int merchant);
	boolean removeInventory(int inventory);

}
