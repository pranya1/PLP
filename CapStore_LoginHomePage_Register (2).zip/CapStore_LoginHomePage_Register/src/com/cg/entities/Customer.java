package com.cg.entities;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Customer implements Serializable{
	@Id
	@GeneratedValue
	private int customerId;
	//@NotEmpty(message="please enter valid email")
	@Pattern(regexp ="^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message="enter valid email")
	private String emailId;
	//@NotEmpty(message="Please enter your password")
	@Size(min=5,max=10,message="password should be between 5 to 10")
	private String password;
	@NotEmpty(message="name is mandatory")
	private String customerName;
	@ManyToMany
	@JoinTable(name="customer_wishlist", joinColumns= {@JoinColumn(name="customerid")},inverseJoinColumns= {@JoinColumn(name="wishlist")})
	private List<Inventory> wishList=new ArrayList<Inventory>();
	@ManyToMany
	@JoinTable(name="customer_cart", joinColumns= {@JoinColumn(name="customerid")},inverseJoinColumns= {@JoinColumn(name="cart")})
	private List<Inventory> cart=new ArrayList<Inventory>();
	private String address;
	private String cardNumber;
	@OneToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="customer")
	private List<Coupons> coupons=new ArrayList<Coupons>();
	private double money;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public List<Inventory> getWishList() {
		return wishList;
	}
	public void setWishList(Inventory wishList) {
		this.wishList.add(wishList);
	}
	public List<Inventory> getCart() {
		return cart;
	}
	public void setCart(Inventory cart) {
		this.cart.add(cart);
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public List<Coupons> getCoupons() {
		return coupons;
	}
	public void setCoupons(Coupons coupons1) {
		this.coupons.add(coupons1);
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public Customer(String emailId, String password, String customerName, String address) {
		super();
		this.emailId = emailId;
		this.password = password;
		this.customerName = customerName;
		this.address = address;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", emailId=" + emailId + ", password=" + password
				+ ", customerName=" + customerName + ", wishList=" + wishList + ", cart=" + cart + ", address="
				+ address + ", cardNumber=" + cardNumber + ", coupons=" + coupons + "]";
	}
	
	
}
