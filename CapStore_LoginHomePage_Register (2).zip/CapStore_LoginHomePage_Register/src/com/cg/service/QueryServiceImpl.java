package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDAO;
import com.cg.entities.Customer;
import com.cg.entities.Merchant;

@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDAO iQueryDAO;
	
	

	@Override
	public void plp() {
		iQueryDAO.plp();
	}



	@Override
	public Merchant saveMerchant(Merchant merchant) {
		// TODO Auto-generated method stub
		return iQueryDAO.saveMerchant(merchant);
	}



	@Override
	public Customer saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return iQueryDAO.saveCustomer(customer);
	}

	
}
