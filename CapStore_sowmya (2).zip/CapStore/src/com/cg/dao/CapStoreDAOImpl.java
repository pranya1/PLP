package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

@Repository
public class CapStoreDAOImpl implements ICapStoreDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00, 0.00);
	     inventory.setMerchant(merchant);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.flush();
		
	}

	@Override
	public List<Customer> showDetails() {
		TypedQuery<Customer> query=entityManager.createQuery("select c from Customer c",Customer.class);
		return query.getResultList();
	}

	@Override
	public List<Inventory> show() {
		TypedQuery<Inventory> query=entityManager.createQuery("select i from Inventory i",Inventory.class);
		return query.getResultList();
	}

	@Override
	public List<Inventory> findByType(String inventoryType) {
		//Inventory inventoryType1=entityManager.find(Inventory.class, inventoryType);
		TypedQuery<Inventory> query=entityManager.createQuery("select i from Inventory i where inventoryType=:type",Inventory.class);
		query.setParameter("type",inventoryType);
		return query.getResultList();
	}

	@Override
	public Inventory findById(int inventoryId) {
		Inventory inventoryId1=entityManager.find(Inventory.class, inventoryId);
		return inventoryId1;
	}

	@Override
	public Customer findCustId(int customerId) {
		Customer customerId1=entityManager.find(Customer.class, customerId);
		return customerId1;
	}

	@Override
	public Merchant findMerchantId(int merchantId) {
		Merchant merchantId1=entityManager.find(Merchant.class, merchantId);
		
		return merchantId1;
	}

	@Override
	public List<Inventory> findByName(String inventoryName) {
		//Inventory inventoryName1=entityManager.find(Inventory.class, inventoryName);
		TypedQuery<Inventory> query=entityManager.createQuery("select i from Inventory i where inventoryType=:name",Inventory.class);
		query.setParameter("name",inventoryName);
		return query.getResultList();
	}

	@Override
	public List<Inventory> findMerchantInventory(int customerId) {
		TypedQuery<Inventory> query=entityManager.createQuery("select i from Inventory i where i.merchant.merchantId=2",Inventory.class);
		//query.setParameter("in", customerId);
		return query.getResultList();
	}

	

	
}
