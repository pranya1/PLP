package com.cg.dao;

import java.util.List;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

public interface ICapStoreDAO {
	
	void plp();
	//public Customer searchCustomer(int customerId);
	public List<Customer> showDetails();
	/*public Admin findAdmin(int adminId);
	public Merchant findMerchant(int merchantId); */
	public List<Inventory> show();
	public List<Inventory> findByType(String inventoryType);
	public Inventory findById(int inventoryId);
	public Customer findCustId(int customerId);
	public Merchant findMerchantId(int merchantId);
	public List<Inventory> findByName(String inventoryName);
	List<Inventory> findMerchantInventory(int customerId);

}
	