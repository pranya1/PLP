package com.cg.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.service.ICapStoreService;

@Controller
public class CapStoreController {
	
	@Autowired
	ICapStoreService iCapStoreService;
	
	
	@RequestMapping("/index")
	public String index() {
		iCapStoreService.plp();

		List<Inventory> inventory=	iCapStoreService.findMerchantInventory(4);
		for(Inventory invent:inventory) {
			System.out.println(invent);
		}
		return "index";
	}


	@RequestMapping("")
	public String findByType(Model model,int isAdmin,int isCustomer,int isMerchant,String inventoryName,String inventoryType,int customerId,int merchantId,int inventoryId) {
		if(isAdmin==1) {
			if(iCapStoreService.findByType(inventoryType)!=null) {
				model.addAttribute("inventory", iCapStoreService.findByType(inventoryType));
				
			}
			else if(iCapStoreService.findCustId(customerId)!=null){
				model.addAttribute("customer", iCapStoreService.findCustId(customerId));
			}
			else if(iCapStoreService.findMerchantId(merchantId)!=null) {
				model.addAttribute("merchant", iCapStoreService.findMerchantId(merchantId));
			}
			else if(iCapStoreService.findById(inventoryId)!=null) {
				model.addAttribute("inventory", iCapStoreService.findById(inventoryId));
			}
		}
		else if(isCustomer==1) {
			if(iCapStoreService.findByType(inventoryType)!=null) {
				model.addAttribute("inventory", iCapStoreService.findByType(inventoryType));
			}
			else if(iCapStoreService.findByName(inventoryName)!=null) {
				model.addAttribute("inventory", iCapStoreService.findByName(inventoryName));
			}
		}
		else if(isMerchant==1) {
			if(iCapStoreService.findById(inventoryId)!=null) {
				model.addAttribute("inventory", iCapStoreService.findById(inventoryId));
			}
		}
		return "";
		
	}
	
}
