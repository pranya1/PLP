package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICapStoreDAO;
import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

@Service
@Transactional
public class CapStoreServiceImpl implements ICapStoreService {

	@Autowired
	ICapStoreDAO iCapStoreDAO;
	
	

	@Override
	public void plp() {
		iCapStoreDAO.plp();
	}


	@Override
	public List<Customer> showDetails() {
		// TODO Auto-generated method stub
		return iCapStoreDAO.showDetails();
	}


	@Override
	public  List<Inventory> show() {
		// TODO Auto-generated method stub
		return iCapStoreDAO.show();
	}


	@Override
	public List<Inventory> findByType(String inventoryType) {
		
		return iCapStoreDAO.findByType(inventoryType);
	}


	@Override
	public Inventory findById(int inventoryId) {
		// TODO Auto-generated method stub
		return iCapStoreDAO.findById(inventoryId);
	}


	@Override
	public Customer findCustId(int customerId) {
		// TODO Auto-generated method stub
		return iCapStoreDAO.findCustId(customerId);
	}


	@Override
	public Merchant findMerchantId(int merchantId) {
		// TODO Auto-generated method stub
		return iCapStoreDAO.findMerchantId(merchantId);
	}


	@Override
	public List<Inventory> findByName(String inventoryName) {
		// TODO Auto-generated method stub
		return iCapStoreDAO.findByName(inventoryName);
	}


	@Override
	public List<Inventory> findMerchantInventory(int customerId) {
		// TODO Auto-generated method stub
		return iCapStoreDAO.findMerchantInventory(customerId);
	}

	/*@Override
	public Customer searchCustomer(int customerId) {
		
		return iCapStoreDAO.searchCustomer(customerId);
	}


	@Override
	public Admin findAdmin(int adminId) {
		
		return iCapStoreDAO.findAdmin(adminId);
	}


	@Override
	public Merchant findMerchant(int merchantId) {
		// TODO Auto-generated method stub
		return iCapStoreDAO.findMerchant(merchantId);
	}

*/


	
}
