package com.cg.dao;

import com.cg.entities.Searching;

public interface SearchDao {
	public Searching searchCustomer(int customerId);
	public Searching viewItems();
	public Searching searchProduct(String products);
	public Searching searchBrand(String brand);
}
