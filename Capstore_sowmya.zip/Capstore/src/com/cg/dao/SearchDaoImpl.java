package com.cg.dao;

import com.cg.entities.Searching;

public class SearchDaoImpl implements SearchDao{

	@Override
	public Searching searchCustomer(int customerId) {
		
		return null;
	}

	@Override
	public Searching viewItems() {
		
		return null;
	}

	@Override
	public Searching searchProduct(String products) {
		
		return null;
	}

	@Override
	public Searching searchBrand(String brand) {
		
		return null;
	}

}
