package com.cg.entities;

public class Searching {
private int customerId;
private String customerName;
private String products;
private String brand;
private String items;
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getProducts() {
	return products;
}
public void setProducts(String products) {
	this.products = products;
}
public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}
public String getItems() {
	return items;
}
public void setItems(String items) {
	this.items = items;
}
@Override
public String toString() {
	return "Searching [customerId=" + customerId + ", customerName=" + customerName + ", products=" + products
			+ ", brand=" + brand + ", items=" + items + "]";
}

}
