package com.cg.service;

import com.cg.entities.Searching;

public class SearchServiceImpl implements SearchService{

	@Override
	public Searching searchCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Searching viewItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Searching searchProduct(String products) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Searching searchBrand(String brand) {
		// TODO Auto-generated method stub
		return null;
	}

}
