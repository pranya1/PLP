package com.cg.service;

import com.cg.entities.Searching;

public interface SearchService{
public Searching searchCustomer(int customerId);
public Searching viewItems();
public Searching searchProduct(String products);
public Searching searchBrand(String brand);
}
